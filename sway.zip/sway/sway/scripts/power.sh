#!/bin/bash
echo "L : Logout"
echo "U : Suspend"
echo "H : Hibernate"
echo "S : Shutdown"
echo "R : Reboot"

read -n 1 ans;

case $ans in
    r|R)
        systemctl reboot;;
    s|S)
        systemctl poweroff;;
    l|L)
        loginctl terminate-user $USER;;
    u|U)
        systemctl suspend;;
    h|H)
        systemctl hibernate;;
    *)
        exit;;
esac
